The demos here are demos that were distributed with GLCD v3

The GLCDv3 directory is the demos as they were shipped with GLCD v3
other than the main header has been changed to use the openGLCD
GLCDv3 compatibility mode.
Some of these will contain warnings.

The openGLCD directory is the demos slightly modified/updated to
use some of the new openGLCDv3 functionality as well as
remove all warnings.
