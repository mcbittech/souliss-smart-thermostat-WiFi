var page_wiring =
[
    [ "KS0108 Family", "page_ks0108_family.html", null ],
    [ "SED1520", "page_sed1520_family.html", null ]
];