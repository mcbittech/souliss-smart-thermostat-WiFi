var annotated =
[
    [ "glcd", "classglcd.html", "classglcd" ],
    [ "glcd_Device", "classglcd___device.html", "classglcd___device" ],
    [ "gText", "classg_text.html", "classg_text" ]
];