var searchData=
[
  ['readdata',['ReadData',['../classglcd___device.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd_Device']]]
];
