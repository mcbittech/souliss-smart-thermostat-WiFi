var searchData=
[
  ['erasetextline',['EraseTextLine',['../classg_text.html#ab89a344bbfc41da84203cd080696cd64',1,'gText::EraseTextLine(eraseLine_t type=eraseTO_EOL)'],['../classg_text.html#ac8afd1f1a935626c4e63114fb7dd8379',1,'gText::EraseTextLine(uint8_t row)']]]
];
