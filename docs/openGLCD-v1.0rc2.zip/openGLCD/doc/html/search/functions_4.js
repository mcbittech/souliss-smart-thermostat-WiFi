var searchData=
[
  ['getareaprop',['GetAreaProp',['../classg_text.html#af290ccc4d819586f87171902ddb96359',1,'gText']]],
  ['gotoxy',['GotoXY',['../classglcd.html#ad978a02751c30279e2db0663d17b9df2',1,'glcd::GotoXY()'],['../classglcd___device.html#ad978a02751c30279e2db0663d17b9df2',1,'glcd_Device::GotoXY()']]],
  ['gtext',['gText',['../classg_text.html#a16a960ba97f7980c603d2185e5b13c54',1,'gText::gText()'],['../classg_text.html#ac62f1c29ceb9b7cccee3576ffa7c9cb4',1,'gText::gText(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, gTextMode mode=DEFAULT_gTEXTMODE)'],['../classg_text.html#ad6bd6c4000c137b49d84bfbdc47dbbe9',1,'gText::gText(predefinedArea selection, gTextMode mode=DEFAULT_gTEXTMODE)'],['../classg_text.html#a097a943bc0b5faf1d40f125ae79a9ede',1,'gText::gText(predefinedArea selection, Font_t font, gTextMode mode=DEFAULT_gTEXTMODE)'],['../classg_text.html#a444609a619f54ceb42930cc5a64f629d',1,'gText::gText(uint8_t x1, uint8_t y1, uint8_t columns, uint8_t rows, Font_t font, gTextMode mode=DEFAULT_gTEXTMODE)']]]
];
