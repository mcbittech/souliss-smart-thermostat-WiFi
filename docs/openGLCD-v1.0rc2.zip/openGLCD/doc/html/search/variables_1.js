var searchData=
[
  ['centerx',['CenterX',['../classglcd.html#aa8546e0626837aeeeee6de4c7bee0f63',1,'glcd']]],
  ['centery',['CenterY',['../classglcd.html#a2203e004a9de1456ea6a80cdbd47d1e9',1,'glcd']]]
];
