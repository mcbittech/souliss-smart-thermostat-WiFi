var searchData=
[
  ['sketch_20migration',['Sketch Migration',['../page__g_l_c_dv3sketch.html',1,'page_libmigrate']]],
  ['specifying_20pins',['Specifying Pins',['../page_pindefines.html',1,'page_configuring']]],
  ['sed1520',['SED1520',['../page_sed1520_family.html',1,'page_wiring']]]
];
