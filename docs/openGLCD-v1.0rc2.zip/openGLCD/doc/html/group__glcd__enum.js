var group__glcd__enum =
[
    [ "gTextfmt_col", "group__glcd__enum.html#ga4d189f94cc52afd4ee4ff1fa1d3e0ca7", null ],
    [ "gTextfmt_row", "group__glcd__enum.html#gaf7baa6af598dd1bfd67b876bd2a87988", null ],
    [ "eraseLine_t", "group__glcd__enum.html#gae849cc01d60a535299bbb59a22b68bc4", [
      [ "eraseTO_EOL", "group__glcd__enum.html#ggae849cc01d60a535299bbb59a22b68bc4ad6e8b4352a3e3d2a4b5b6bc7bd0f43f9", null ],
      [ "eraseFROM_BOL", "group__glcd__enum.html#ggae849cc01d60a535299bbb59a22b68bc4af8ab05b484adb5d2d5017b679ba9079d", null ],
      [ "eraseFULL_LINE", "group__glcd__enum.html#ggae849cc01d60a535299bbb59a22b68bc4a7c56077d12e2d37ca2be1715d8fef3d1", null ],
      [ "eraseNONE", "group__glcd__enum.html#ggae849cc01d60a535299bbb59a22b68bc4af1197397666542bf3d8b88b3057797c5", null ]
    ] ],
    [ "gTextfmt_t", "group__glcd__enum.html#gaa42ab7cad2413f125d864b504e2ee909", [
      [ "gTextfmt_left", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909afce147558670e93d3e3d321e48286a28", null ],
      [ "gTextfmt_right", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909ab74a840881add68e75779cc640c0da94", null ],
      [ "gTextfmt_top", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909ac9a2187edd52100f44205435871d789c", null ],
      [ "gTextfmt_bottom", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909a0477f64d678f12f07df0db47163e2d43", null ],
      [ "gTextfmt_center", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909a42017755324dbd8efc9830b7463b374e", null ],
      [ "gTextfmt_current", "group__glcd__enum.html#ggaa42ab7cad2413f125d864b504e2ee909a8cfdee9795c132ff4a94a91db707b905", null ]
    ] ],
    [ "gTextMode", "group__glcd__enum.html#gadc961ca1c8936ce7bc7aae778a8a84e7", [
      [ "gTextMode_SCROLLDOWN", "group__glcd__enum.html#ggadc961ca1c8936ce7bc7aae778a8a84e7ab9abdd35061a1d58b0dcb1c13656ca2f", null ],
      [ "gTextMode_VARasFIXED", "group__glcd__enum.html#ggadc961ca1c8936ce7bc7aae778a8a84e7a8e0252dfd939a948731ddc2215946f2f", null ],
      [ "gTextMode_OVERSTRIKE", "group__glcd__enum.html#ggadc961ca1c8936ce7bc7aae778a8a84e7a9d4c77cdd2c295bd4ad66a50031d07d1", null ]
    ] ],
    [ "gTextProp_t", "group__glcd__enum.html#gacdd60064702e4b0cc2f353082db3f615", [
      [ "gTextProp_x1", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615ad531b5cd7a88e67c0df6eb741bcb1b1c", null ],
      [ "gTextProp_y1", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615ad6d1e6e51b2da80a29b45fe8ec1974b3", null ],
      [ "gTextProp_x2", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a7daaefb49b523f14fe6fc931c92b9e7b", null ],
      [ "gTextProp_y2", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a89876f2ad505e6bd4121dffe4070a4ef", null ],
      [ "gTextProp_cols", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a8825130c69e66b274b87246c66197ebb", null ],
      [ "gTextProp_rows", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615ab814900b5413e4be960fb332901090c6", null ],
      [ "gTextProp_FontWidth", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615af41dd3847a08c474a6c2e5558145e881", null ],
      [ "gTextProp_FontHeight", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a495fdb0fb81d8244d36356c46ee73fe8", null ],
      [ "gTextProp_minC", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a78999871605e0eeaf10f0db2b8923166", null ],
      [ "gTextProp_maxC", "group__glcd__enum.html#ggacdd60064702e4b0cc2f353082db3f615a58f33533101d9d4fbd1b3a420b0e12c0", null ]
    ] ],
    [ "predefinedArea", "group__glcd__enum.html#ga7c9059506d7e1ad7da54dd3a5cd7d8ff", [
      [ "textAreaFULL", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa491df2530b6d4ad7e4b74c8b8b9c9665", null ],
      [ "textAreaTOP", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa1b1759158aca4bfab09d86a1ab20ef0b", null ],
      [ "textAreaBOTTOM", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa0e7ed149f7bf89d646b66d6654814ad8", null ],
      [ "textAreaLEFT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffaf0ad62af3c0fbcc89fcc6a0664c64d05", null ],
      [ "textAreaRIGHT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa24d90120c369fc18f69c711638b84a8c", null ],
      [ "textAreaTOPLEFT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa53f2e913ffc1a00b73094ea3d3c3e72b", null ],
      [ "textAreaTOPRIGHT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffadc9fb0c3f606dc8d3f7941a14d2becd0", null ],
      [ "textAreaBOTTOMLEFT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa93569f00806e314884ae039023a98d42", null ],
      [ "textAreaBOTTOMRIGHT", "group__glcd__enum.html#gga7c9059506d7e1ad7da54dd3a5cd7d8ffa3b490c448f69ea2263bd919bd022bf23", null ]
    ] ]
];