var page__g_l_c_d__a_p_i =
[
    [ "GLCD coordinate system", "page_coordinates.html", null ],
    [ "GLCD object API functions", "page__g_l_c_d_object.html", null ],
    [ "gText API functions", "page_g_text_object.html", null ],
    [ "Arduino print Functions", "page_arduino_print.html", null ]
];