var page_libmigrate =
[
    [ "Migrating Configurations", "page__g_l_c_dv3config.html", null ],
    [ "Sketch Migration", "page__g_l_c_dv3sketch.html", null ],
    [ "Fonts and Bitmaps", "page__g_l_c_dv3fontbitmap.html", null ]
];